import java.io.IOException;

public class CalculationDemo {
    public static void main(String[] args) throws IOException {
        CalculationService service = new CalculationService();
        service.calculate();
    }
}