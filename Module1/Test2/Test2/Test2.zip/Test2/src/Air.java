public interface Air {
    public void fly();
}
