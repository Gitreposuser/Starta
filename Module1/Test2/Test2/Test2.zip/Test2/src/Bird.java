public class Bird implements Air {
    public void fly() {
        System.out.println(" Bird can fly ");
    }
}
