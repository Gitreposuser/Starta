public class Main {
    public static void main(String[] args) {
        Bird bird = new Bird();
        Lizzard lizzard = new Lizzard();
        Ornithosaurian orni = new Ornithosaurian();

        bird.fly();
        lizzard.run();
        orni.fly();
        orni.run();
    }
}