public class Lizzard implements Ground {
    public void run() {
        System.out.println(" Lizzard can crawl ");
    }
}
