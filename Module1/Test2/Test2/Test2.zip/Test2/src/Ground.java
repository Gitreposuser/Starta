public interface Ground {
    public void run();
}
