import java.util.Scanner;

public class UI {
    public static String inputLine() {
        return new Scanner(System.in).nextLine();
    }
}
